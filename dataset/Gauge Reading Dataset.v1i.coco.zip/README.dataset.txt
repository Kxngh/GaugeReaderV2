# Gauge Reading Dataset > 2024-12-13 4:01pm
https://universe.roboflow.com/assignment-codds/gauge-reading-dataset

Provided by a Roboflow user
License: CC BY 4.0

